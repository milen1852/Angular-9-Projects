// import { Injectable } from "@angular/core";
// import { CanActivate, Router } from "@angular/router";
// import { AuthService } from "./auth.service";

// @Injectable({ providedIn: 'root' })
// export class AuthGuard implements CanActivate {

//   constructor(
//     private authService: AuthService,
//     private router: Router
//   ) {}

//   canActivate(): boolean {

//     // ✅ Allow navigation if ANY token exists
//     if (this.authService.hasAnyToken()) {
//       return true;
//     }

//     // ❌ Redirect ONLY if no tokens at all
//     this.router.navigate(['/login']);
//     return false;
//   }
// }

import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AuthService } from './auth.service';

@Injectable({ providedIn: 'root' })
export class AuthGuard implements CanActivate {

  constructor(private auth: AuthService, private router: Router) {}

  canActivate(): boolean {
    if (this.auth.getAccessToken() || this.auth.getRefreshToken()) {
      console.log("Has Token")
      return true;
    }
    console.log("No Token")
    this.router.navigate(['/login']);
    return false;
  }
}

