import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { EmployeeService } from 'src/app/employee/employee.service';
import { Employee } from '../models/employee-department';

@Component({
  selector: 'app-get-department-id',
  templateUrl: './get-department-id.component.html',
  styleUrls: ['./get-department-id.component.css']
})
export class GetDepartmentIdComponent implements OnInit {

  constructor(
      private router: ActivatedRoute,
      private employeeService: EmployeeService,
      private toastr: ToastrService
    ) {}
  
  employee!: Employee;
  
  ngOnInit(): void {
  
    // 1️⃣ Try getting from navigation state
    const navEmployee = history.state.employee;
  
    if (navEmployee) {
      this.employee = navEmployee;
      return;
    }
  
    // 2️⃣ Fallback: fetch using route param
    const empId = Number(this.router.snapshot.paramMap.get('empId'));
  
    if (!empId) {
      this.toastr.error('Invalid Employee ID');
      return;
    }
  
    this.employeeService.getEmployeeWithDepartment(empId).subscribe({
      next: res => this.employee = res,
      error: () => {
        this.toastr.error('Employee Not Found');
      }
    });
  }  
}
