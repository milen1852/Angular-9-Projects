export interface DepartmentResponseDTO {
  name: string;
  location: string;
}

export interface Employee {
  empId: number;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  deptId: number;
  departmentResponseDTO: DepartmentResponseDTO;
  salary: number;
  status: string;
  hireDate: Date;
}