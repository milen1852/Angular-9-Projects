import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../models/employee';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-get-employee',
  templateUrl: './get-employee.component.html',
  styleUrls: ['./get-employee.component.css']
})
export class GetEmployeeComponent implements OnInit {

  employees: Employee[] = [];

  page = 0;
  size = 5;
  totalPages = 0;
  totalElements = 0;
  pages: number[] = [];

  search = '';
  deptId: number | null = null;
  minSalary: number | null = null;
  maxSalary: number | null = null;
  status = '';

  selectedEmployee: Employee | null = null;

  constructor(
    private employeeService: EmployeeService,
    private router: Router,
    private toastr: ToastrService
  ) {}

  ngOnInit() {
    this.loadEmployees();
  }

  loadEmployees() {
    const params: any = {
      page: this.page,
      size: this.size
    };

    if (this.search) params.search = this.search;
    if (this.deptId !== null) params.deptId = this.deptId;
    if (this.minSalary !== null) params.minSalary = this.minSalary;
    if (this.maxSalary !== null) params.maxSalary = this.maxSalary;
    if (this.status) params.status = this.status;

    this.employeeService.getEmployees(params).subscribe({
      next: (res) => {
        this.employees = res.content;
        this.page = res.currentPage;
        this.totalPages = res.totalPages;
        this.totalElements = res.totalElements;

        this.pages = Array.from({ length: this.totalPages }, (_, i) => i);
      }
    });
  }

  goToPage(p: number) {
    if (p >= 0 && p < this.totalPages) {
      this.page = p;
      this.loadEmployees();
    }
  }

  nextPage() {
    if (this.page < this.totalPages - 1) {
      this.page++;
      this.loadEmployees();
    }
  }

  prevPage() {
    if (this.page > 0) {
      this.page--;
      this.loadEmployees();
    }
  }

  searchEmployees() {
    this.page = 0;
    this.loadEmployees();
  }

  resetFilters() {
    this.search = '';
    this.deptId = null;
    this.minSalary = null;
    this.maxSalary = null;
    this.status = '';
    this.page = 0;
    this.loadEmployees();
  }

  onRowClick(employee: Employee) {
    this.selectedEmployee = employee;
  }

  editEmployee() {
    if (!this.selectedEmployee) return;
    this.employeeService.setSelectedEmployee(this.selectedEmployee);
    this.router.navigate(['/update-employee']);
  }

  deleteEmployee() {
    if (!this.selectedEmployee) return;
    this.employeeService.setSelectedEmployee(this.selectedEmployee);
    this.router.navigate(['/delete-employee']);
  }


  searchEmpId!: number;

  searchByEmployeeId(){
    if(!this.searchEmpId){
      this.toastr.warning("Please Enter Employee Id")
      return;
    }

      this.employeeService.getEmployeeWithDepartment(this.searchEmpId).subscribe({
    next: () => {
      // ✅ Employee exists → Navigate
      this.router.navigate(
        ['/get-departmentId', this.searchEmpId]
      );
    },
    error: () => {
      this.toastr.error('Employee Not Found');
    }
  });
  }

}
