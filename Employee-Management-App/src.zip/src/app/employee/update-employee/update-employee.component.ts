import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-update-employee',
  templateUrl: './update-employee.component.html',
  styleUrls: ['./update-employee.component.css']
})
export class UpdateEmployeeComponent implements OnInit {

  constructor(private employeeService: EmployeeService, private router: Router, private toastr: ToastrService) { }

  employee: any = {};
statuses: string[] = [];

ngOnInit() {
  this.employee = this.employeeService.getSelectedEmployee();

  if (!this.employee) {
    this.router.navigate(['/get-employees']);
    return;
  }

  this.employeeService.getStatus().subscribe(
    data => this.statuses = data
  );
}

updateEmployee() {
  this.employeeService.updateEmployee(this.employee).subscribe({
    next: () => {
      this.toastr.success('Employee updated successfully');
      this.router.navigate(['/get-employees']);
    },
    error: (err) => {
      console.log('Error response:', err); // 🔍 IMPORTANT

      let errorMessage = '';

      if (err.error) {
        if (typeof (err.error) === 'string') {
          errorMessage = err.error;
        } else if (err.error.message) {
          errorMessage = err.error.message;
        }
      }

      this.toastr.error(errorMessage);
    }
  });
}


}
