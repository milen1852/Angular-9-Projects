import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Employee } from '../department/models/employee-department';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  private baseUrl = 'http://localhost:8081/api';

  constructor(private http: HttpClient) { }

  getEmployees(params: any){
    return this.http.get<any>(`${this.baseUrl}/employees`, {params})
  }

  addEmployee(data: any){
    return this.http.post(`${this.baseUrl}/employee`, data);
  }

  getStatus() {
  return this.http.get<string[]>(`${this.baseUrl}/employee/meta/status`);
  }

  updateEmployee(employee: any) {
    return this.http.put(`${this.baseUrl}/employee/${employee.empId}`,employee);
  }

  deleteEmployee(empId: number) {
    return this.http.delete(`${this.baseUrl}/employee/${empId}`);
  }

  getEmployeeWithDepartment(empId: number) {
    return this.http.get<Employee>(`${this.baseUrl}/employee/${empId}`);
  }

  private selectedEmployee: any;

setSelectedEmployee(emp: any) {
  this.selectedEmployee = emp;
}

getSelectedEmployee() {
  return this.selectedEmployee;
}
}
