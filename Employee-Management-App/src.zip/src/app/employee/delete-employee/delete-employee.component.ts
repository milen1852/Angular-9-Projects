import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-delete-employee',
  templateUrl: './delete-employee.component.html',
  styleUrls: ['./delete-employee.component.css']
})
export class DeleteEmployeeComponent implements OnInit {

  constructor(private employeeService: EmployeeService, private router: Router, private toastr: ToastrService) { }

  employee: any = {};
confirmDelete: string = '';

ngOnInit() {
  this.employee = this.employeeService.getSelectedEmployee();

  if (!this.employee) {
    this.router.navigate(['/employees']);
  }
}

deleteEmployee() {
  if (this.confirmDelete !== 'YES') {
    this.toastr.info('Deletion cancelled');
    this.router.navigate(['/get-employees']);
    return;
  }

  this.employeeService.deleteEmployee(this.employee.empId).subscribe({
    next: () => {
      this.toastr.success('Employee deleted successfully');
      this.router.navigate(['/get-employees']);
    },
    error: (err) => {
      console.log('Error response:', err); // 🔍 IMPORTANT

      let errorMessage = 'Something went wrong';

      if (err.error) {
        if (typeof err.error === 'string') {
          errorMessage = err.error;
        } else if (err.error.message) {
          errorMessage = err.error.message;
        }
      }

      this.toastr.error(errorMessage);
    }
  });
}


}
