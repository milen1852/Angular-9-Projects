export interface Employee {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  deptId: number;
  salary: number;
  status: string;
  hireDate: Date;
}
